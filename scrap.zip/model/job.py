from pydantic import BaseModel

class Job(BaseModel):
    title:str
    company:str
    location:str
    time_opened:str
    # company_img:str
    # link:str
        
    

