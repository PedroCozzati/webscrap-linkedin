from bs4 import BeautifulSoup
import requests
import urllib.parse
import itertools
import pandas as pd

from controller.web_connection import WebConnection
from model.job import Job

estado = 'São Paulo,'
cidade = 'São Paulo,'
pais = 'Brazil'
trabalho = 'Desenvolvedor'
distance = '40'

connection = WebConnection(
    url='https://www.linkedin.com/jobs/',
    keyword=trabalho,
    estado=estado,
    cidade=cidade,
    pais=pais,
    distance=distance
)

data = connection.start_connection()

soup = BeautifulSoup(data.text,'html.parser')

titles = soup.find_all('h3',{'class':['base-search-card__title']})
companies = soup.find_all('h4', {'class':['base-search-card__subtitle', 'hidden-nested-link']})
locations = soup.find_all('span',{'class':'job-search-card__location'})
jobs_time_opened = soup.find_all('time',{'class':['base-search-card__metadata','job-search-card__listdate','job-search-card__listdate--new']})
links = soup.find_all('a',{'class':'href'})


job_list=[]
title_list=[]
company_list=[]
location_list=[]
time_opened_list=[]

def get_info():
    for title in titles:
        title = title.text.strip()
        title_list.append(title)
    # company = company.text.strip()
    # job =Job(title=title,company=company)
    # job_list.append(job)
    for company in companies:
        company = company.text.strip()
        company_list.append(company)
        # company = company.text.strip()
        
    for location in locations:
        location = location.text.strip()
        location_list.append(location)
        # print(location)
        
    for time_opened in jobs_time_opened:
        time_opened = time_opened.text.strip()
        time_opened_list.append(time_opened)
    
        # job = Job(title=title,company=company,location=location,time_opened=time_opened)
        # job_list.append(job)
            
        
    # print(job_list)
get_info()

print(len(title_list))
print(len(company_list))
print(len(location_list))
print(len(time_opened_list))

df = pd.DataFrame.from_dict({
    'title': title_list,
    'company':company_list,
    'location':location_list,
    'time_opened':time_opened_list
})

df.to_csv("linkedin_jobs",sep=',',index=False)
